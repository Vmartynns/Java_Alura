package Calculos;

public interface Classificavel {
    int getClassificacao();



    
}
